# BEM VINDO GAFANHOTO

# SSH-PLUS

# @jailondanet

*PROJETO EM ANDAMENTO...
*CÓPIA DE CÓPIA DE CÓPIA KKK

# Modo de instalação
# 👇👽👍
Só joga na máquina e deixar instalar

• atualiza sistema

• desativa Ipv6

• instala recursos e o script
```
apt install wget -y; bash <(wget -qO- wget raw.githubusercontent.com/jailondanet2/Script/main/script/${arch}/Plus && chmod 777 Plus && ./Plus)

```
